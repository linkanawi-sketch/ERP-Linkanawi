const express = require('express');
const router = express.Router();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const { authMiddleware } = require('../lib/auth');

router.get('/', authMiddleware, async (req, res) => {
  const students = await prisma.student.findMany();
  res.json(students);
});

router.post('/', authMiddleware, async (req, res) => {
  const data = req.body;
  const student = await prisma.student.create({ data });
  res.json(student);
});

module.exports = router;

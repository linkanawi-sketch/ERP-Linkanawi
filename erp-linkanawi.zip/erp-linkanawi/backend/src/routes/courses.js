const express = require('express');
const router = express.Router();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const { authMiddleware } = require('../lib/auth');

router.get('/', authMiddleware, async (req, res) => {
  const courses = await prisma.course.findMany();
  res.json(courses);
});

router.post('/', authMiddleware, async (req, res) => {
  const course = await prisma.course.create({ data: req.body });
  res.json(course);
});

module.exports = router;

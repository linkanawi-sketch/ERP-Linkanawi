const express = require('express');
const router = express.Router();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const { authMiddleware } = require('../lib/auth');

router.get('/', authMiddleware, async (req, res) => {
  const list = await prisma.payment.findMany();
  res.json(list);
});

router.post('/', authMiddleware, async (req, res) => {
  const data = req.body;
  const p = await prisma.payment.create({ data });
  res.json(p);
});

module.exports = router;

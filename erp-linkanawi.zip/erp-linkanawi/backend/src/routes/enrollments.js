const express = require('express');
const router = express.Router();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const { authMiddleware } = require('../lib/auth');

router.get('/', authMiddleware, async (req, res) => {
  const enrollments = await prisma.enrollment.findMany();
  res.json(enrollments);
});

router.post('/', authMiddleware, async (req, res) => {
  const data = req.body;
  const e = await prisma.enrollment.create({ data });
  res.json(e);
});

module.exports = router;

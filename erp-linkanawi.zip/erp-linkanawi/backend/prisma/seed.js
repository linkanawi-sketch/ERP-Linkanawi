const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const bcrypt = require('bcrypt');

async function main(){
  const pw = await bcrypt.hash('admin123', 10);
  await prisma.user.upsert({
    where: { email: 'admin@linkanawi.com' },
    update: {},
    create: {
      email: 'admin@linkanawi.com',
      password: pw,
      role: 'admin'
    }
  });

  const curso = await prisma.course.create({
    data: {
      title: 'Ofimática Básica',
      level: 'Básico',
      description: 'Curso de ofimática para principiantes',
      price: 120.0
    }
  });

  const student = await prisma.student.create({
    data: {
      dni: '12345678',
      firstName: 'María',
      lastName: 'Pérez',
      email: 'maria.perez@example.com',
      phone: '987654321'
    }
  });

  await prisma.enrollment.create({
    data: {
      studentId: student.id,
      courseId: curso.id,
      startDate: new Date(),
      active: true
    }
  });

  console.log('Seed completo');
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });

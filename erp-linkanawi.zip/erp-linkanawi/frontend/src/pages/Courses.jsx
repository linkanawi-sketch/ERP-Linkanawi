import { useEffect, useState } from 'react';
import api from '../api';

export default function Courses(){
  const [courses, setCourses] = useState([]);
  useEffect(()=>{
    async function load(){
      const token = localStorage.getItem('token');
      const res = await api.get('/courses', { headers: { Authorization: `Bearer ${token}` } });
      setCourses(res.data);
    }
    load();
  },[]);
  return (
    <div style={{padding:24}}>
      <h2>Cursos</h2>
      <ul>
        {courses.map(c => <li key={c.id}>{c.title} - {c.level}</li>)}
      </ul>
    </div>
  );
}

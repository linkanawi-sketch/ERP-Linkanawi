import { useEffect, useState } from 'react';
import api from '../api';

export default function Students(){
  const [students, setStudents] = useState([]);
  useEffect(()=>{
    async function load(){
      const token = localStorage.getItem('token');
      const res = await api.get('/students', { headers: { Authorization: `Bearer ${token}` } });
      setStudents(res.data);
    }
    load();
  },[]);
  return (
    <div style={{padding:24}}>
      <h2>Alumnos</h2>
      <ul>
        {students.map(s => <li key={s.id}>{s.firstName} {s.lastName}</li>)}
      </ul>
    </div>
  );
}

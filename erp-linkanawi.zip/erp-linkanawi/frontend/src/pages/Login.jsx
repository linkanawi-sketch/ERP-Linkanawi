import { useState } from 'react';
import api from '../api';

export default function Login(){
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  async function submit(e){
    e.preventDefault();
    const res = await api.post('/auth/login',{ email, password });
    localStorage.setItem('token', res.data.token);
    window.location = '/';
  }
  return (
    <div style={{padding:24}}>
      <h1>Login</h1>
      <form onSubmit={submit}>
        <div>
          <input placeholder="email" value={email} onChange={e=>setEmail(e.target.value)} />
        </div>
        <div>
          <input placeholder="password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        </div>
        <div>
          <button type="submit">Entrar</button>
        </div>
      </form>
    </div>
  );
}
